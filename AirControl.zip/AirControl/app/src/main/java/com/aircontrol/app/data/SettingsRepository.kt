package com.aircontrol.app.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "air_control_settings")

data class AirSettings(
    val sensitivity: Float = 1.6f,
    val smoothing: Float = 0.5f,
    val pinchThreshold: Float = 0.05f,
    val longPressDelayMs: Long = 650L,
    val isLeftHanded: Boolean = false,
    val debugMode: Boolean = false
)

class SettingsRepository(private val context: Context) {
    companion object {
        val KEY_SENSITIVITY = floatPreferencesKey("sensitivity")
        val KEY_SMOOTHING = floatPreferencesKey("smoothing")
        val KEY_PINCH_THRESHOLD = floatPreferencesKey("pinch_threshold")
        val KEY_LONG_PRESS_MS = longPreferencesKey("long_press_ms")
        val KEY_LEFT_HANDED = booleanPreferencesKey("is_left_handed")
        val KEY_DEBUG_MODE = booleanPreferencesKey("debug_mode")
    }

    val settingsFlow: Flow<AirSettings> = context.dataStore.data.map { pref ->
        AirSettings(
            sensitivity = pref[KEY_SENSITIVITY] ?: 1.6f,
            smoothing = pref[KEY_SMOOTHING] ?: 0.5f,
            pinchThreshold = pref[KEY_PINCH_THRESHOLD] ?: 0.05f,
            longPressDelayMs = pref[KEY_LONG_PRESS_MS] ?: 650L,
            isLeftHanded = pref[KEY_LEFT_HANDED] ?: false,
            debugMode = pref[KEY_DEBUG_MODE] ?: false
        )
    }

    suspend fun updateSensitivity(value: Float) {
        context.dataStore.edit { it[KEY_SENSITIVITY] = value }
    }

    suspend fun updateSmoothing(value: Float) {
        context.dataStore.edit { it[KEY_SMOOTHING] = value }
    }

    suspend fun updateDebugMode(value: Boolean) {
        context.dataStore.edit { it[KEY_DEBUG_MODE] = value }
    }
}