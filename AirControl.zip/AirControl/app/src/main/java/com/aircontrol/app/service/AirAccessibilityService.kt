package com.aircontrol.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AirAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AirAccessibilityService? = null
            private set

        val isRunning: Boolean
            get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { instance = null }
    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun performTap(x: Float, y: Float) {
        try {
            val clickPath = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(clickPath, 0, 50))
                .build()
            dispatchGesture(gesture, null, null)
        } catch (_: Exception) {}
    }

    fun performReelNext(width: Float, height: Float) {
        try {
            val path = Path().apply {
                moveTo(width / 2f, height * 0.78f)
                lineTo(width / 2f, height * 0.22f)
            }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 220))
                .build()
            dispatchGesture(gesture, null, null)
        } catch (_: Exception) {}
    }

    fun performReelPrev(width: Float, height: Float) {
        try {
            val path = Path().apply {
                moveTo(width / 2f, height * 0.22f)
                lineTo(width / 2f, height * 0.78f)
            }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 220))
                .build()
            dispatchGesture(gesture, null, null)
        } catch (_: Exception) {}
    }

    // Air Keyboard Text Injection
    fun typeText(text: String) {
        try {
            val root = rootInActiveWindow ?: return
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
            val currentText = focused.text?.toString() ?: ""
            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, currentText + text)
            }
            focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
        } catch (_: Exception) {}
    }

    fun deleteText() {
        try {
            val root = rootInActiveWindow ?: return
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
            val currentText = focused.text?.toString() ?: ""
            if (currentText.isNotEmpty()) {
                val arguments = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, currentText.dropLast(1))
                }
                focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            }
        } catch (_: Exception) {}
    }
}