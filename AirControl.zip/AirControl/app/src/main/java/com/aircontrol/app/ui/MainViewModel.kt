package com.aircontrol.app.ui

import android.app.Application
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aircontrol.app.data.AirSettings
import com.aircontrol.app.data.SettingsRepository
import com.aircontrol.app.service.AirAccessibilityService
import com.aircontrol.app.service.CameraTrackingService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AppUiState(
    val isTrackingRunning: Boolean = false,
    val isAccessibilityEnabled: Boolean = false,
    val isOverlayPermissionGranted: Boolean = false,
    val isCameraPermissionGranted: Boolean = false,
    val settings: AirSettings = AirSettings()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = SettingsRepository(application)
    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repo.settingsFlow.collect { newSettings ->
                _uiState.value = _uiState.value.copy(settings = newSettings)
            }
        }
        refreshStatus()
    }

    fun refreshStatus() {
        val context = getApplication<Application>()
        val hasOverlay = Settings.canDrawOverlays(context)
        val hasAccessibility = AirAccessibilityService.isRunning
        val isServiceOn = CameraTrackingService.isServiceRunning

        _uiState.value = _uiState.value.copy(
            isOverlayPermissionGranted = hasOverlay,
            isAccessibilityEnabled = hasAccessibility,
            isTrackingRunning = isServiceOn
        )
    }

    fun toggleTracking(start: Boolean) {
        val context = getApplication<Application>()
        val intent = Intent(context, CameraTrackingService::class.java)
        if (start) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } else {
            context.stopService(intent)
        }
        refreshStatus()
    }

    fun updateSensitivity(value: Float) {
        viewModelScope.launch { repo.updateSensitivity(value) }
    }

    fun updateSmoothing(value: Float) {
        viewModelScope.launch { repo.updateSmoothing(value) }
    }
}