package com.aircontrol.app.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aircontrol.app.service.CameraTrackingService
import com.aircontrol.app.ui.AppUiState

@Composable
fun DashboardScreen(
    state: AppUiState,
    onToggleTracking: (Boolean) -> Unit,
    onSensitivityChange: (Float) -> Unit,
    onSmoothingChange: (Float) -> Unit,
    onOpenTraining: () -> Unit,
    onOpenPrivacy: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(18.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "AirControl Pro",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Air Mouse • Training Mode • Air Keyboard",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Main Start/Stop Switch
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (state.isTrackingRunning) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = if (state.isTrackingRunning) "Air Control ACTIVE" else "Air Control OFF",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (state.isTrackingRunning) "Gestures live • Charging ring on" else "Switch on to start",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = state.isTrackingRunning,
                    enabled = state.isAccessibilityEnabled && state.isOverlayPermissionGranted,
                    onCheckedChange = { onToggleTracking(it) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Fast Action Buttons: Training & Air Keyboard
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onOpenTraining,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
            ) {
                Text("🎯 Hand Training", fontSize = 13.sp)
            }

            Button(
                onClick = {
                    val intent = Intent(context, CameraTrackingService::class.java).apply {
                        putExtra("TOGGLE_KEYBOARD", true)
                    }
                    context.startService(intent)
                },
                enabled = state.isTrackingRunning,
                modifier = Modifier.weight(1f)
            ) {
                Text("⌨️ Air Keyboard", fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("🛡️ Anti-Accidental Click Guide", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text("• Faltu Click Khatam: Pinch karne par mouse par red ring bharegi. Ring poori hote hi tap hoga.", fontSize = 12.sp)
                Text("• Agar galti se haath chhua, ring cancel ho jayegi (No accidental tap!).", fontSize = 12.sp)
                Text("• Reels Swipe: Ungli upar jhatkein to Next Reel, niche jhatkein to Prev Reel.", fontSize = 12.sp)
                Text("• Auto-Home: Haath hat te hi mouse screen ke niche center me ruk jayega.", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("⚙️ Sensitivity & Speed", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(10.dp))

                Text("Mouse Speed: ${String.format("%.1f", state.settings.sensitivity)}x", fontSize = 13.sp)
                Slider(
                    value = state.settings.sensitivity,
                    onValueChange = onSensitivityChange,
                    valueRange = 0.4f..1.8f
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text("Smoothness: ${String.format("%.0f", state.settings.smoothing * 100)}%", fontSize = 13.sp)
                Slider(
                    value = state.settings.smoothing,
                    onValueChange = onSmoothingChange,
                    valueRange = 0.4f..0.95f
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Required Permissions", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(8.dp))
                PermissionRow(
                    name = "Accessibility Touch Engine",
                    isGranted = state.isAccessibilityEnabled,
                    onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                )
                Spacer(modifier = Modifier.height(6.dp))
                PermissionRow(
                    name = "Floating Overlay Permission",
                    isGranted = state.isOverlayPermissionGranted,
                    onClick = { context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = onOpenPrivacy) {
            Text("Privacy Policy & Guarantee")
        }
    }
}

@Composable
fun PermissionRow(name: String, isGranted: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                contentDescription = null,
                tint = if (isGranted) Color(0xFF34A853) else Color(0xFFEA4335)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(name, fontSize = 13.sp)
        }
        if (!isGranted) {
            OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
                Text("Fix", fontSize = 12.sp)
            }
        }
    }
}