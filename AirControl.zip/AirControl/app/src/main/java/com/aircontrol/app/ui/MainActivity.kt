package com.aircontrol.app.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModelProvider
import com.aircontrol.app.ui.screens.DashboardScreen
import com.aircontrol.app.ui.screens.PrivacyScreen
import com.aircontrol.app.ui.screens.TrainingScreen

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            viewModel = ViewModelProvider(
                this,
                ViewModelProvider.AndroidViewModelFactory.getInstance(application)
            )[MainViewModel::class.java]
        } catch (e: Exception) {
            viewModel = MainViewModel(application)
        }

        setContent {
            MaterialTheme {
                val state by viewModel.uiState.collectAsState()
                var currentScreen by remember { mutableStateOf("dashboard") }

                when (currentScreen) {
                    "training" -> TrainingScreen(onBack = { currentScreen = "dashboard" })
                    "privacy" -> PrivacyScreen(onBack = { currentScreen = "dashboard" })
                    else -> DashboardScreen(
                        state = state,
                        onToggleTracking = { viewModel.toggleTracking(it) },
                        onSensitivityChange = { viewModel.updateSensitivity(it) },
                        onSmoothingChange = { viewModel.updateSmoothing(it) },
                        onOpenTraining = { currentScreen = "training" },
                        onOpenPrivacy = { currentScreen = "privacy" }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::viewModel.isInitialized) {
            viewModel.refreshStatus()
        }
    }
}