package com.aircontrol.app.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView

class AirKeyboardManager(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var keyboardView: View? = null
    var isVisible = false
        private set

    private val keys = listOf(
        "Q","W","E","R","T","Y","U","I","O","P",
        "A","S","D","F","G","H","J","K","L",
        "Z","X","C","V","B","N","M", "⌫", "Space", "Close"
    )

    fun toggle() {
        if (isVisible) hide() else show()
    }

    fun show() {
        mainHandler.post {
            if (isVisible) return@post
            val layout = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#E6202124"))
                setPadding(16, 16, 16, 24)
            }

            val title = TextView(context).apply {
                text = "⌨️ Air Keyboard (Hover & Click to Type)"
                setTextColor(Color.WHITE)
                textSize = 14f
                gravity = Gravity.CENTER
            }
            layout.addView(title)

            val grid = GridLayout(context).apply {
                columnCount = 10
                rowCount = 3
            }

            for (key in keys) {
                val btn = Button(context).apply {
                    text = key
                    textSize = 12f
                    setTextColor(Color.WHITE)
                    setBackgroundColor(Color.parseColor("#3C4043"))
                    setOnClickListener {
                        handleKey(key)
                    }
                }
                grid.addView(btn)
            }
            layout.addView(grid)

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUS_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM
            }

            try {
                windowManager.addView(layout, params)
                keyboardView = layout
                isVisible = true
            } catch (_: Exception) {}
        }
    }

    private fun handleKey(key: String) {
        val acc = AirAccessibilityService.instance ?: return
        when (key) {
            "Close" -> hide()
            "Space" -> acc.typeText(" ")
            "⌫" -> acc.deleteText()
            else -> acc.typeText(key)
        }
    }

    fun hide() {
        mainHandler.post {
            if (isVisible && keyboardView != null) {
                try {
                    windowManager.removeView(keyboardView)
                } catch (_: Exception) {}
                keyboardView = null
                isVisible = false
            }
        }
    }
}