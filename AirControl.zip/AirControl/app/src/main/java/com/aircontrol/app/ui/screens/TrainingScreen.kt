package com.aircontrol.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TrainingScreen(onBack: () -> Unit) {
    var step by remember { mutableStateOf(1) }
    var practiceCount by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🎯 Gesture Training & Calibration", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Step $step of 3", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        }

        when (step) {
            1 -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Lesson 1: Controlled Movement", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Apne haath ki index finger ko dheere se hilayein. Mouse ko screen ke chaaron kono me le jakar practice karein.", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(30.dp))
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .background(Color(0xFF4285F4), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Target", color = Color.WHITE)
                    }
                }
            }
            2 -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Lesson 2: Charging Ring Click", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Ungli aur angutha milayein (Pinch). Mouse ke chaaron taraf red circle bharega aur tap hoga. Faltu click bilkul nahi honge!", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(30.dp))
                    Button(onClick = { practiceCount++ }) {
                        Text("Practice Clicks: $practiceCount")
                    }
                }
            }
            3 -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Lesson 3: Reels & Shorts Flick", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Ungli ko hawa me upar ki taraf jhatkein to Agli Reel scroll hogi. Niche jhatkein to Pichli Reel scroll hogi!", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(30.dp))
                    Text("🎉 You are ready to control your phone in the air!", color = Color(0xFF34A853), fontWeight = FontWeight.Bold)
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = onBack) {
                Text("Exit Training")
            }
            Button(onClick = {
                if (step < 3) step++ else onBack()
            }) {
                Text(if (step < 3) "Next Lesson" else "Finish & Start")
            }
        }
    }
}