package com.aircontrol.app.domain

sealed class GestureAction {
    data class Move(val x: Float, val y: Float) : GestureAction()
    data class Click(val x: Float, val y: Float) : GestureAction()
    data class LongPress(val x: Float, val y: Float) : GestureAction()
    data class Drag(val startX: Float, val startY: Float, val endX: Float, val endY: Float) : GestureAction()
    data class Scroll(val startX: Float, val startY: Float, val deltaY: Float) : GestureAction()
    object Back : GestureAction()
    object Home : GestureAction()
}

enum class VisualCursorState {
    NORMAL,
    HOVER,
    PINCHED,
    LONG_PRESS,
    SCROLLING,
    DISABLED
}