package com.aircontrol.app.domain

import kotlin.math.PI
import kotlin.math.abs

class OneEuroFilter(
    private val minCutoff: Double = 1.0,
    private val beta: Double = 0.007,
    private val dCutoff: Double = 1.0
) {
    private var xPrev = 0.0
    private var dxPrev = 0.0
    private var tPrev: Long = -1

    fun filter(x: Double, timestampMs: Long): Double {
        if (tPrev < 0) {
            tPrev = timestampMs
            xPrev = x
            dxPrev = 0.0
            return x
        }

        val dt = (timestampMs - tPrev) / 1000.0
        if (dt <= 0.0) return xPrev

        tPrev = timestampMs
        val dx = (x - xPrev) / dt
        val edx = exponentialSmoothing(dx, dxPrev, alpha(dt, dCutoff))
        dxPrev = edx

        val cutoff = minCutoff + beta * abs(edx)
        val ex = exponentialSmoothing(x, xPrev, alpha(dt, cutoff))
        xPrev = ex
        return ex
    }

    private fun alpha(dt: Double, cutoff: Double): Double {
        val tau = 1.0 / (2.0 * PI * cutoff)
        return 1.0 / (1.0 + tau / dt)
    }

    private fun exponentialSmoothing(a: Double, b: Double, alpha: Double): Double {
        return alpha * a + (1.0 - alpha) * b
    }

    fun reset() {
        tPrev = -1
    }
}