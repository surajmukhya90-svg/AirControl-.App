package com.aircontrol.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.aircontrol.app.AirControlApp
import com.aircontrol.app.domain.OneEuroFilter
import com.aircontrol.app.domain.VisualCursorState
import com.aircontrol.app.tracking.HandTrackingAnalyzer
import com.aircontrol.app.ui.MainActivity
import java.util.concurrent.Executors
import kotlin.math.hypot

class CameraTrackingService : Service(), LifecycleOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private var overlayManager: CursorOverlayManager? = null
    var keyboardManager: AirKeyboardManager? = null
        private set

    private var analyzer: HandTrackingAnalyzer? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val filterX = OneEuroFilter(minCutoff = 0.5, beta = 0.002)
    private val filterY = OneEuroFilter(minCutoff = 0.5, beta = 0.002)

    private var lastHandSeenTime = 0L
    private var pinchStartTime = 0L
    private var isPinchHolding = false
    private var lastTapTime = 0L
    private var lastSwipeTime = 0L

    private var prevIndexY = -1f
    private var prevSwipeSampleTime = 0L

    override val lifecycle: Lifecycle get() = lifecycleRegistry

    companion object {
        var instance: CameraTrackingService? = null
            private set
        var isServiceRunning = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            lifecycleRegistry.currentState = Lifecycle.State.CREATED
            lifecycleRegistry.currentState = Lifecycle.State.STARTED
            lifecycleRegistry.currentState = Lifecycle.State.RESUMED

            overlayManager = CursorOverlayManager(this)
            keyboardManager = AirKeyboardManager(this)
            overlayManager?.show()
            isServiceRunning = true

            startAutoHomeLoop()
        } catch (_: Exception) {}
    }

    private fun startAutoHomeLoop() {
        val metrics = resources.displayMetrics
        val homeX = metrics.widthPixels / 2f
        val homeY = metrics.heightPixels * 0.88f

        mainHandler.post(object : Runnable {
            override fun run() {
                if (!isServiceRunning) return
                try {
                    val now = SystemClock.uptimeMillis()
                    if (now - lastHandSeenTime > 650L) {
                        overlayManager?.returnToHome(homeX, homeY)
                        pinchStartTime = 0L
                        isPinchHolding = false
                    }
                } catch (_: Exception) {}
                mainHandler.postDelayed(this, 30L)
            }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            if (intent?.getBooleanExtra("TOGGLE_KEYBOARD", false) == true) {
                keyboardManager?.toggle()
                return START_STICKY
            }
            val notification = createNotification()
            startForeground(101, notification)
            startCameraAnalysis()
        } catch (_: Exception) {}
        return START_STICKY
    }

    private fun startCameraAnalysis() {
        try {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    val metrics = resources.displayMetrics
                    val screenWidth = metrics.widthPixels.toFloat()
                    val screenHeight = metrics.heightPixels.toFloat()

                    analyzer = HandTrackingAnalyzer(
                        context = this,
                        onResult = { result, timestamp ->
                            try {
                                val landmarks = result.landmarks()
                                if (!landmarks.isNullOrEmpty() && landmarks[0].size > 20) {
                                    lastHandSeenTime = timestamp
                                    val hand = landmarks[0]

                                    val wrist = hand[0]
                                    val thumbTip = hand[4]
                                    val indexTip = hand[8]
                                    val middleTip = hand[12]
                                    val ringTip = hand[16]

                                    // 1. Slow, Controlled, Non-Shaky Movement
                                    val rawScreenX = (indexTip.x() * screenWidth).coerceIn(0f, screenWidth)
                                    val rawScreenY = (indexTip.y() * screenHeight).coerceIn(0f, screenHeight)

                                    val smoothX = filterX.filter(rawScreenX.toDouble(), timestamp).toFloat()
                                    val smoothY = filterY.filter(rawScreenY.toDouble(), timestamp).toFloat()

                                    overlayManager?.updatePosition(smoothX, smoothY)

                                    // 2. Anti-Accidental Click with Charging Ring (Zero Faltu Clicks)
                                    val pinchDist = hypot((thumbTip.x() - indexTip.x()).toDouble(), (thumbTip.y() - indexTip.y()).toDouble()).toFloat()
                                    val indexToWrist = hypot((indexTip.x() - wrist.x()).toDouble(), (indexTip.y() - wrist.y()).toDouble()).toFloat()
                                    val middleToWrist = hypot((middleTip.x() - wrist.x()).toDouble(), (middleTip.y() - wrist.y()).toDouble()).toFloat()
                                    val ringToWrist = hypot((ringTip.x() - wrist.x()).toDouble(), (ringTip.y() - wrist.y()).toDouble()).toFloat()

                                    val isPinchOrFist = pinchDist < 0.08f || (indexToWrist < 0.27f && middleToWrist < 0.27f && ringToWrist < 0.27f)

                                    if (isPinchOrFist) {
                                        if (!isPinchHolding) {
                                            isPinchHolding = true
                                            pinchStartTime = timestamp
                                        }
                                        val holdDuration = timestamp - pinchStartTime
                                        val progress = (holdDuration / 350f).coerceIn(0f, 1f)
                                        overlayManager?.setClickProgress(progress)

                                        // Click only fires when user deliberately holds pinch for 350ms!
                                        if (holdDuration >= 350L && (timestamp - lastTapTime > 500L)) {
                                            lastTapTime = timestamp
                                            overlayManager?.updateState(VisualCursorState.PINCHED)
                                            AirAccessibilityService.instance?.performTap(smoothX, smoothY)
                                        }
                                    } else {
                                        isPinchHolding = false
                                        pinchStartTime = 0L
                                        overlayManager?.setClickProgress(0f)
                                        overlayManager?.updateState(VisualCursorState.NORMAL)
                                    }

                                    // 3. Reels Swipe (Flick UP = Next Reel, Flick DOWN = Prev Reel)
                                    if (timestamp - prevSwipeSampleTime > 150L) {
                                        if (prevIndexY > 0f && (timestamp - lastSwipeTime > 750L)) {
                                            val deltaY = indexTip.y() - prevIndexY
                                            if (deltaY < -0.15f) {
                                                lastSwipeTime = timestamp
                                                overlayManager?.updateState(VisualCursorState.SCROLLING)
                                                AirAccessibilityService.instance?.performReelNext(screenWidth, screenHeight)
                                            } else if (deltaY > 0.15f) {
                                                lastSwipeTime = timestamp
                                                overlayManager?.updateState(VisualCursorState.SCROLLING)
                                                AirAccessibilityService.instance?.performReelPrev(screenWidth, screenHeight)
                                            }
                                        }
                                        prevIndexY = indexTip.y()
                                        prevSwipeSampleTime = timestamp
                                    }
                                }
                            } catch (_: Exception) {}
                        },
                        onError = { }
                    )

                    val analysisUseCase = ImageAnalysis.Builder()
                        .setTargetResolution(Size(480, 640))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                        .also {
                            it.setAnalyzer(cameraExecutor, analyzer!!)
                        }

                    val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(this, cameraSelector, analysisUseCase)
                } catch (_: Exception) {}
            }, ContextCompat.getMainExecutor(this))
        } catch (_: Exception) {}
    }

    private fun createNotification(): Notification {
        val channelId = "aircontrol_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "AirControl Active", NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("AirControl Active")
            .setContentText("Hold pinch to tap, Flick up/down for Reels")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        isServiceRunning = false
        try {
            lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
            analyzer?.close()
            cameraExecutor.shutdown()
            keyboardManager?.hide()
            overlayManager?.hide()
        } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null
}